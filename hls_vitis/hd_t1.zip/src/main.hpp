
#ifndef MAIN_H
#define MAIN_H
#include <hls_stream.h>
#include "ap_axi_sdata.h"

#include <stdint.h>

#define NUM_OF_RAW_DATA 7797
#define NUM_OF_RAW_TRAIN 5000
#define NUM_OF_RAW_TEST 50

#define NUM_OF_FEATURES 617
#define NUM_OF_LEVEL 100
#define NUM_OF_CLASS 26

#define THR 0

#define APP_EXAMPLE  "isolet"
#define ITERATION 	 20
#define HD_DIM 		 1024
#define DATA_WIDTH_BITS 2
#define BASE_VAL 0b11
#define DATAW_WIDTH_BITS 16

#define STATE_FIRST_FEATURE  1
#define STATE_LAST_FEATURE   2

#define SOUT_CLASSIFICATION_WIDTH_BITS 5
#define SIN_STATE_WIDTH_BITS 5

typedef ap_axiu<8,1,1,1> AXI_VALUE;
typedef hls::stream<AXI_VALUE> AXI_STREAM;

extern "C" {
void hdv_engine(bool &reset_input, AXI_STREAM& stream_data_input, ap_uint<SOUT_CLASSIFICATION_WIDTH_BITS> *class_result_output);
}
void readAndUpdateData(ap_uint<DATA_WIDTH_BITS>& temp_val1, int8_t& temp_data1, ap_uint<DATA_WIDTH_BITS>& temp_val2,
		int8_t& temp_data2, uint16_t& bv_index1, uint16_t& bv_index2, uint16_t& lv_index1, uint16_t& lv_index2);
void processHDVector(int8_t* HyperDimensionalVector);
void findClass(int8_t* HyperDimensionalVector, ap_uint<SOUT_CLASSIFICATION_WIDTH_BITS>& find_class);


#endif
