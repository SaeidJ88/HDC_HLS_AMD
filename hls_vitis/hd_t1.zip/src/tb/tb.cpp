#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <thread>
#include <iostream>
#include <fstream>
#include "ap_axi_sdata.h"
#include <hls_stream.h>
#include <ap_int.h>
#include <cstdlib>
#include <vector>
#include <numeric>
#include <iostream>

#include "../data.hpp"

#include "../main.hpp"

#define FILE_DATA_IN      "D://hd//hls//src//tb//test_data.txt"

#define NUM_TEST_DATA 1159

typedef ap_axiu<8,1,1,1> AXI_VALUE; // AXI4-Stream value type
typedef hls::stream<AXI_VALUE> AXI_STREAM; // AXI4-Stream type

int main() {

    // Definitions
    AXI_STREAM sdata_i;
    ap_uint<SOUT_CLASSIFICATION_WIDTH_BITS> class_result_o;

    static bool nrst_i;
    typedef uint8_t data_t;

    nrst_i = 0;
    hdv_engine(nrst_i, sdata_i, &class_result_o);
    nrst_i = 1;

    std::ifstream file(FILE_DATA_IN);
    if (!file.is_open()) {
        std::cout << "Failed to open file.\n";
        return -1;
    }

    std::string line;
    std::string token;
    int data;

    // Variables for performance metrics
    int passCount = 0;
    int failCount = 0;

    // Initialize confusion matrix
    std::vector<std::vector<int>> confusionMatrix(NUM_OF_CLASS, std::vector<int>(NUM_OF_CLASS, 0));

    while (std::getline(file, line)) {
        std::istringstream lineStream(line);
        int j = 0;
        while (std::getline(lineStream, token, ',')) {
            std::istringstream tokenStream(token);
            if (tokenStream >> data) {
                if (j <= NUM_OF_FEATURES-1) {
                    AXI_VALUE aValue; // Create an AXI4-Stream value
                    aValue.data = data; // Setting data
                    aValue.last = (j == NUM_OF_FEATURES-1); // Setting last signal to 1 if it's the last feature
                    sdata_i.write(aValue); // Writing to AXI Stream
                    hdv_engine(nrst_i, sdata_i, &class_result_o);
                }

                if (j == NUM_OF_FEATURES) {
                    std::cout << "TEST " << passCount + failCount << " = " << static_cast<int>(class_result_o) << ",LABEL=" << data << "\n";

                    // Update confusion matrix
                    confusionMatrix[data-1][static_cast<int>(class_result_o)-1]++;

                    if (static_cast<int>(class_result_o) == data) {
                        passCount++;
                    } else {
                        failCount++;
                    }
                }
            } else {
                std::cout << "Failed to read data at row " << passCount + failCount << ", col " << j << "\n";
                break;
            }
            j++;
        }
    }

    file.close();

    // Calculate accuracy
    double accuracy = static_cast<double>(passCount) / static_cast<double>(passCount + failCount);
    std::cout << "Accuracy: " << accuracy << "\n";

    // Calculate metrics for each class
    for (int i = 0; i < NUM_OF_CLASS; i++) {
        int tp = confusionMatrix[i][i];
        int fp = std::accumulate(confusionMatrix[i].begin(), confusionMatrix[i].end(), 0) - tp;
        int fn = std::accumulate(confusionMatrix.begin(), confusionMatrix.end(), 0, [i](int sum, const std::vector<int>& row) { return sum + row[i]; }) - tp;

        double precision = static_cast<double>(tp) / (tp + fp);
        double recall = static_cast<double>(tp) / (tp + fn);
        double f1Score = 2 * ((precision * recall) / (precision + recall));

        std::cout << "Class " << i+1 << " - Precision: " << precision << ", Recall: " << recall << ", F1 Score: " << f1Score << "\n";
    }

    return 0;
}
