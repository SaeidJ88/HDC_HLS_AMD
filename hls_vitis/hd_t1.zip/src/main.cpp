#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "ap_int.h"
#include <math.h>
#include "main.hpp"
#include <hls_stream.h>
#include "ap_axi_sdata.h"

#include "data.hpp"




extern "C" {
void hdv_engine(bool &reset_input, AXI_STREAM& stream_data_input, ap_uint<SOUT_CLASSIFICATION_WIDTH_BITS> *class_result_output) {
#pragma HLS INTERFACE axis port=stream_data_input
#pragma HLS INTERFACE s_axilite port=reset_input bundle=CTRL_BUS
#pragma HLS INTERFACE s_axilite port=class_result_output bundle=CTRL_BUS
#pragma HLS INTERFACE s_axilite port=return bundle=CTRL_BUS


	AXI_VALUE aValue;

    static int8_t HyperDimensionalVector[HD_DIM];
    static uint16_t feature_id = 0;
    ap_uint<DATA_WIDTH_BITS> temp_val1, temp_val2;
    int8_t temp_data1, temp_data2;
    uint8_t feature;
    static uint16_t bv_index1=0, bv_index2=0;
    static uint16_t lv_index1 = 0, lv_index2 = 0;

    static ap_uint<SOUT_CLASSIFICATION_WIDTH_BITS> find_class;

    // Resetting and initializing values
    if (reset_input == 0 || feature_id == 0) {
        feature_id = 0;
        for ( int i = 0; i < HD_DIM; i++ ) {
            HyperDimensionalVector[i] = 0;
        }
        lv_index1 = 0;
        lv_index2 = 0;
        bv_index1 = 0;
        bv_index2 = 0;
    }
    if (reset_input != 0) {
        // Reading the features and updating the Hyper Dimensional Vector
        if ( feature_id < NUM_OF_FEATURES ) {

        	aValue = stream_data_input.read();
        	feature = aValue.data;

            if (feature >= 100) feature = 99;
            lv_index1 = feature * 32;
            for ( int i = 0; i < HD_DIM; i++ ){
                readAndUpdateData(temp_val1, temp_data1, temp_val2, temp_data2, bv_index1, bv_index2, lv_index1, lv_index2);
                HyperDimensionalVector[i] += (temp_data1 * temp_data2);
            }
        }

        // Processing after reading all features
        if ( feature_id == NUM_OF_FEATURES - 1 ){
            processHDVector(HyperDimensionalVector);
            findClass(HyperDimensionalVector, find_class);

            feature_id=0;

        }else{
            feature_id++;
        }
    }

    *class_result_output = find_class;
}

}

void readAndUpdateData(ap_uint<DATA_WIDTH_BITS>& temp_val1, int8_t& temp_data1, ap_uint<DATA_WIDTH_BITS>& temp_val2, int8_t& temp_data2, uint16_t& bv_index1, uint16_t& bv_index2, uint16_t& lv_index1, uint16_t& lv_index2) {
    temp_val1 = BV[bv_index1].range(bv_index2+DATA_WIDTH_BITS-1, bv_index2);
    bv_index2 = bv_index2 + DATA_WIDTH_BITS;
    if (bv_index2 == 64) {
        bv_index2 = 0;
        bv_index1 = bv_index1 + 1;
    }

    if (temp_val1 == 3){
        temp_data1 = -1;
    }else{
        temp_data1 = temp_val1;
    }

    temp_val2 = LV[lv_index1].range(lv_index2+DATA_WIDTH_BITS-1, lv_index2);
    lv_index2 = lv_index2 + DATA_WIDTH_BITS;
    if (lv_index2 == 64) {
        lv_index2 = 0;
        lv_index1 = lv_index1 + 1;
    }

    if (temp_val2 == 3){
        temp_data2 = -1;
    }else{
        temp_data2 = temp_val2;
    }
}

void processHDVector(int8_t* HyperDimensionalVector) {
    for ( int i = 0; i < HD_DIM; i++ ) {
        if ( HyperDimensionalVector[i] > THR ) {
            HyperDimensionalVector[i] = 1;
        }
        if ( HyperDimensionalVector[i] == THR ) {
            HyperDimensionalVector[i] = 0;
        }
        if ( HyperDimensionalVector[i] < THR ) {
            HyperDimensionalVector[i] = -1;
        }
    }
}

void findClass(int8_t* HyperDimensionalVector, ap_uint<SOUT_CLASSIFICATION_WIDTH_BITS>& find_class) {
    int disimilarity_max = 0;
    int disimilarity = 0;
    int temp_index1=0, temp_index2=0;
    int val_w;
    int8_t temp_val1;
    int norm_HV1 = 0, norm_HV2 = 0;
    int dot = 0;

    for ( int i = 0; i < HD_DIM; i++ ) {
        norm_HV2 = norm_HV2 + (HyperDimensionalVector[i] * HyperDimensionalVector[i]);
    }
    norm_HV2 = sqrt(norm_HV2);

    for ( int i = 0; i < NUM_OF_CLASS; i++ ) {
        dot = 0;
        for ( int j = 0; j < HD_DIM; j++ ) {
            val_w = W[temp_index1].range(temp_index2+DATAW_WIDTH_BITS-1, temp_index2);

            temp_index2 = temp_index2 + DATAW_WIDTH_BITS;
            if (temp_index2 == 64){
                temp_index2 = 0;
                temp_index1 = temp_index1 + 1;
            }
            if (val_w>=32768)val_w = -(val_w-32768);

            norm_HV1 = norm_HV1 + (val_w * val_w);

            dot = dot + ( val_w * HyperDimensionalVector[j] );
        }

        norm_HV1 = sqrt(norm_HV1);

        disimilarity = (dot * 10000) / (norm_HV1 * norm_HV2);
        if (disimilarity > disimilarity_max){
            disimilarity_max = disimilarity;
            find_class = i+1;
        }
    }
}
