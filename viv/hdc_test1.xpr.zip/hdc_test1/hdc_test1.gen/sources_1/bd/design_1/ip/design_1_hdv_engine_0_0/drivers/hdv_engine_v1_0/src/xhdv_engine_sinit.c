// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xhdv_engine.h"

extern XHdv_engine_Config XHdv_engine_ConfigTable[];

XHdv_engine_Config *XHdv_engine_LookupConfig(u16 DeviceId) {
	XHdv_engine_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHDV_ENGINE_NUM_INSTANCES; Index++) {
		if (XHdv_engine_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHdv_engine_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHdv_engine_Initialize(XHdv_engine *InstancePtr, u16 DeviceId) {
	XHdv_engine_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHdv_engine_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHdv_engine_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

